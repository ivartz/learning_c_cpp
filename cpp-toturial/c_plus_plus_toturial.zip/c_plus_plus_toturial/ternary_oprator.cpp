#include <iostream>
#include <vector>
#include <string>
#include <fstream>

using namespace std;

// This is a comment
/*
 * this is a multiline comment
 *
*/

int main()
{
    // conditional (ternary) operator
    // variable = (condition) ? true : false

    //int largestNum = (5>2) ? 5 : 2;
    return 0;
}
